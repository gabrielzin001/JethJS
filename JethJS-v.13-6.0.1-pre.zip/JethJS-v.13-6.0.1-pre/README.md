![JETH](https://i.imgur.com/NybGppe.png)

<h1 align="center">⭐ Jethzinha ⭐</h1>

<p align="center">
<a href="https://top.gg/bot/718210363014905866">
  <img src="https://top.gg/api/widget/718210363014905866.svg">
</a>
</p>

<p>Os servidores do Discord necessitam de uma moderação de qualidade, pois sofrem do mesmo problema, pessoas má intencionadas que querem lhe causar problemas, porém não queremos uma santa inquisição ou até mesmo que nossos servidores pareçam uma ditadura não é mesmo? pensando nisso foram criados os bots dentro do Discord, disponibilizando ferramentas para que seja feita uma moderação adequada e muito bem organizada, a Jeth é um deles, uma robô com Múltiplos Propósitos focada em Moderação de servidores, também contamos com diversos comandos de entretenimento e miscelânea.</p>

## 💎 Features

### 👮‍♀️ Trust & Safety
- A Jeth conta agora com um sistema que foi muito utilizado pela Loritta um tempo atrás que se chama blacklist, esta função faz com que membros que estejam dentro desta categoria não possam usar os comandos da Jeth e sejam banidas de uma rede de servidores em que o módulo esteja ATIVO, este módulo é customizável, ou seja, você pode decidir se ele estará ativo ou não e pode alterar quando quiser.
  Um usuário só será adicionado neste módulo caso ele descumpra os termos de serviço do Discord ou cometa alguma infração muito grave a nível superior de moderação básica de servidor.
  
### ☃️ Buttons
- Recentemente lançada nas últimas atualizações do Discord, com buttons fica muito mais fácil a interação do usuário com nossos comandos com ou sem o uso de SlashCommands, dando um olhar mais agradável e bem mais organizado.

### 👮 Moderation
- Contém diversos comandos que irão facilitar sua vida como moderador de um servidor privado ou público, comandos como: `-mute`, `-warn`, `-ban`, `-kick`; entre outros.

### 😘 Fun
- Esta categoria contém comandos de diversão que irão lhe entreter e ajudar a entreter o público do seu servidor contando com comandos clássicos e conhecidos por diversos servidores como o caso do `-ship`

> Também contemos muitos outros módulos e categorias, por favor venha conferir nossa linda robozinha adicionando-a em seu servidor do Discord!
