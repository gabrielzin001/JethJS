module.exports = function (error) {
  this.sendLoggerError(error)
}